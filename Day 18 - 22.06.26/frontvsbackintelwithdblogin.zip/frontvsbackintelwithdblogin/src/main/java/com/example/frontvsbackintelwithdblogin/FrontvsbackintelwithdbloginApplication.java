package com.example.frontvsbackintelwithdblogin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontvsbackintelwithdbloginApplication {

	public static void main(String[] args) {
		SpringApplication.run(FrontvsbackintelwithdbloginApplication.class, args);
	}

}
