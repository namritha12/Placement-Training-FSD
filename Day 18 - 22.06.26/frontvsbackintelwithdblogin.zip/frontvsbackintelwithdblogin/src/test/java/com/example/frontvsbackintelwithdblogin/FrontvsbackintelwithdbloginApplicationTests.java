package com.example.frontvsbackintelwithdblogin;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FrontvsbackintelwithdbloginApplicationTests {

	@Test
	void contextLoads() {
	}

}
